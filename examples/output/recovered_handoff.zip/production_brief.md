# Production handoff

Source revision: 3ca60d4a-ddd2-4737-92db-cf7f0e77867a

Allocate the approved source text across 4 ordered spreads as supplied in spreads.json. Span start/end values are half-open Python Unicode code-point offsets into manuscript.txt. Concatenate span text in spread order to recover the manuscript exactly, including line endings.

Preserve all wording, punctuation, and line breaks. Keep art direction and production notes outside source spans. Any editorial change requires a new revision and separate human approval.

This fixed allocation demonstrates controlled text transfer. An editor and designer still need to decide pacing, pagination, illustration, typography, and print specifications. Text-integrity validation does not certify editorial quality or print readiness.
